package com.gui.listeners;

import com.gui.gui.WelcomeGui;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.player.PlayerJoinEvent;

public class JoinListener implements Listener {

    private final WelcomeGui welcomeGui;

    public JoinListener(WelcomeGui welcomeGui) {
        this.welcomeGui = welcomeGui;
    }

    @EventHandler
    public void onPlayerJoin(PlayerJoinEvent event) {
        Player player = event.getPlayer();

        event.setJoinMessage(null);

        player.sendMessage("§aMerhaba, hoş geldin §e" + player.getName() + "§a!");

        welcomeGui.open(player);
    }
}
