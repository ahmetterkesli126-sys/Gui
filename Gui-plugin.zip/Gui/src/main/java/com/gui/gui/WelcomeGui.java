package com.gui.gui;

import com.gui.GuiPlugin;
import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.Statistic;
import org.bukkit.entity.Player;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;

import java.util.ArrayList;
import java.util.List;

public class WelcomeGui {

    public static final String GUI_TITLE = "§8Hoş Geldin";

    private final GuiPlugin plugin;

    public WelcomeGui(GuiPlugin plugin) {
        this.plugin = plugin;
    }

    public void open(Player player) {
        Inventory gui = Bukkit.createInventory(null, 27, GUI_TITLE);

        ItemStack glass = createItem(Material.GRAY_STAINED_GLASS_PANE, " ", null);
        for (int i = 0; i < 27; i++) {
            gui.setItem(i, glass);
        }

        long playTicks = player.getStatistic(Statistic.PLAY_ONE_MINUTE);
        long totalMinutes = playTicks / 20 / 60;
        long hours = totalMinutes / 60;
        long minutes = totalMinutes % 60;
        String playTime = hours + " saat " + minutes + " dakika";

        int onlineCount = Bukkit.getOnlinePlayers().size();
        String discordLink = plugin.getConfig().getString("discord-link", "discord.gg/example");

        List<String> lore = new ArrayList<>();
        lore.add("§7Merhaba, sunucumuza hoş geldin.");
        lore.add("");
        lore.add("§7Aktif oyuncu sayısı: §f" + onlineCount);
        lore.add("§7Oyunda geçirdiğin süre: §f" + playTime);
        lore.add("§7Discord adresimiz: §f" + discordLink);
        lore.add("");
        lore.add("§aBizi tercih ettiğiniz için teşekkür ederiz.");

        ItemStack info = createItem(Material.BOOK, "§eSunucu Bilgisi", lore);
        gui.setItem(13, info);

        player.openInventory(gui);
    }

    private ItemStack createItem(Material material, String name, List<String> lore) {
        ItemStack item = new ItemStack(material);
        ItemMeta meta = item.getItemMeta();
        if (meta != null) {
            meta.setDisplayName(name);
            if (lore != null) {
                meta.setLore(lore);
            }
            item.setItemMeta(meta);
        }
        return item;
    }
}
