package com.gui;

import com.gui.gui.WelcomeGui;
import com.gui.gui.WelcomeGuiListener;
import com.gui.listeners.JoinListener;
import org.bukkit.plugin.java.JavaPlugin;

public class GuiPlugin extends JavaPlugin {

    @Override
    public void onEnable() {
        saveDefaultConfig();

        WelcomeGui welcomeGui = new WelcomeGui(this);

        getServer().getPluginManager().registerEvents(new JoinListener(welcomeGui), this);
        getServer().getPluginManager().registerEvents(new WelcomeGuiListener(), this);

        getLogger().info("Gui plugin aktif edildi!");
    }

    @Override
    public void onDisable() {
        getLogger().info("Gui plugin devre dışı bırakıldı.");
    }
}
